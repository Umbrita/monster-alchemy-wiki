---
title: Arcane Blast
tags: [neutral, magic, active-skill]
---
<div class="skill-card">
  <div class="skill-header">
    <span class="skill-name">Arcane Blast</span>
    <div class="skill-types">
      <a href="/tags/neutral" class="type-badge"><img src="/assets/icons/T_EType_Normal.PNG" alt="Neutral" class="type-icon" /></a>
      <a href="/tags/magic" class="type-badge"><img src="/assets/icons/T_AType_Magic.PNG" alt="Magic" class="type-icon" /></a>
    </div>
  </div>
  <div class="skill-stats-row">
    <div class="stat-pill skill-power"><span>Power</span><strong>120</strong></div>
    <div class="stat-pill skill-cost"><span>Cost</span><strong>10</strong></div>
    <div class="stat-pill skill-scaling-mind"><span>Scaling</span><strong>Mind</strong></div>
    <div class="stat-pill skill-target"><span>Target</span><strong>Single Enemy (Frontline)</strong></div>
  </div>
  <div class="skill-desc">
    —
  </div>
  <div class="skill-learned-by">
    <h3>Learned By</h3>
    <table>
      <thead>
        <tr><th>Monster</th><th>Level</th></tr>
      </thead>
      <tbody>
        <tr><td><a href="/monsters/floating-armor">Floating Armor</a></td><td>20</td></tr>
      </tbody>
    </table>
  </div>
</div>