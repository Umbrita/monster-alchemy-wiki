---
title: Solidified Cloud
tags: [item]
---
<div class="item-card">
  <div class="item-header">
    <img src="/assets/items/t_solidifiedcloud.PNG" alt="Solidified Cloud" class="item-icon-large" />
    <div class="item-header-text">
      <span class="item-name">Solidified Cloud</span>
      <span class="item-desc">—</span>
    </div>
  </div>

  <div class="item-recipe">
    <h3>Craft Recipe</h3>
    <div class="recipe-meta">
      <a href="/mechanics/rooms/furnace" class="recipe-room">Furnace</a>
      <span class="recipe-work">⚡ 10 Work Power</span>
    </div>
    <table>
      <thead><tr><th>Ingredient</th><th>Amount</th></tr></thead>
      <tbody>
        <tr>
          <td><a href="/items/marine-essence" class="item-ingredient-link"><img src="/assets/items/t_marineessence.PNG" alt="Marine Essence" class="drop-icon" />Marine Essence</a></td>
          <td>20</td>
        </tr>
        <tr>
          <td><a href="/items/muddy-petal" class="item-ingredient-link"><img src="/assets/items/t_muddypetal.PNG" alt="Muddy Petal" class="drop-icon" />Muddy Petal</a></td>
          <td>3</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>