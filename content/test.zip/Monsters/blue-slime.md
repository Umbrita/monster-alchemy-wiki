---
title: Blue Slime
tags: [water, strike, tier1]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Blue Slime</span>
    <a href="/tags/tier1" class="monster-tier">Tier 1</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_BlueSlime.PNG" alt="Blue Slime" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/water" class="type-badge"><img src="/assets/icons/T_EType_Water.PNG" alt="Water" class="type-icon" /></a>
      <a href="/tags/strike" class="type-badge"><img src="/assets/icons/T_AType_Strike.PNG" alt="Strike" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    They are so cold that they freeze the moisture in the air which is why they have icicles.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>50</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>40</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>30</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>50</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>50</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>40</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/sticky-strike">Sticky Strike</a><br/><span class="skill-desc">Inflicts 2 <img id="Slow"/> Slow.</span></td></tr>
          <tr><td>5</td><td><a href="/skills/icicle-dart">Icicle Dart</a><br/><span class="skill-desc">This skill can target any enemy.</span></td></tr>
          <tr><td>18</td><td><a href="/skills/black-waters">Black Waters</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/slimy-texture"><strong>Slimy Texture</strong></a></br> When inflicted by <img id="Shock"/> Shock, gain 1 <img id="Regeneration"/> Regeneration instead.</p>
    </div>
  </div>
  <div class="monster-drops">
    <h3>Drops</h3>
    <table>
      <thead><tr><th>Rarity</th><th>Item</th></tr></thead>
      <tbody>
          <tr><td>Common</td><td><a href="/items/goo" class="item-ingredient-link"><img src="/assets/items/t_goo.PNG" alt="Goo" class="drop-icon" />Goo</a></td></tr>
          <tr><td>Epic</td><td><a href="/items/marine-essence" class="item-ingredient-link"><img src="/assets/items/t_marineessence.PNG" alt="Marine Essence" class="drop-icon" />Marine Essence</a></td></tr>
      </tbody>
    </table>
  </div>

</div>