---
title: Torch Demon
tags: [fire, strike, tier2]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Torch Demon</span>
    <a href="/tags/tier2" class="monster-tier">Tier 2</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_TorchDemon.PNG" alt="Torch Demon" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/fire" class="type-badge"><img src="/assets/icons/T_EType_Fire.PNG" alt="Fire" class="type-icon" /></a>
      <a href="/tags/strike" class="type-badge"><img src="/assets/icons/T_AType_Strike.PNG" alt="Strike" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    The angrier it gets the stronger it burns. But it usually forgets why it is angry.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>65</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>70</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>45</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>70</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>50</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>55</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/scorch-blast">Scorch Blast</a><br/><span class="skill-desc">Inflicts 2 <img id="Burn"/> Burn.</span></td></tr>
          <tr><td>8</td><td><a href="/skills/heat-wave">Heat Wave</a></td></tr>
          <tr><td>18</td><td><a href="/skills/scorch-blast">Scorch Blast</a><br/><span class="skill-desc">Inflicts 2 <img id="Burn"/> Burn.</span></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/hellish-precision"><strong>Hellish Precision</strong></a></br> 25% critical chance against enemies with <img id="Burn"/> Burn.</p>
    </div>
  </div>


</div>