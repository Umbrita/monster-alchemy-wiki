---
title: Monsters
cssclasses:
  - monsters-archive
---

<details class="monster-tier-group" open>
  <summary class="monster-tier-summary">Tier 1 <span class="tier-count">85</span></summary>
  <div class="monster-index-grid">
  <a href="/monsters/slime" class="monster-index-card">
    <img src="/assets/Portraits/P_Slime.PNG" alt="Slime" />
    <span>Slime</span>
  </a>
  <a href="/monsters/stick-golem" class="monster-index-card">
    <img src="/assets/Portraits/P_StickGolem.PNG" alt="Stick Golem" />
    <span>Stick Golem</span>
  </a>
  <a href="/monsters/goblin-pillager" class="monster-index-card">
    <img src="/assets/Portraits/P_GoblinPillager.PNG" alt="Goblin Pillager" />
    <span>Goblin Pillager</span>
  </a>
  <a href="/monsters/goblin-hexer" class="monster-index-card">
    <img src="/assets/Portraits/P_GoblinHexer.PNG" alt="Goblin Hexer" />
    <span>Goblin Hexer</span>
  </a>
  <a href="/monsters/scout" class="monster-index-card">
    <img src="/assets/Portraits/P_Scout.PNG" alt="Scout" />
    <span>Scout</span>
  </a>
  <a href="/monsters/merkid" class="monster-index-card">
    <img src="/assets/Portraits/P_Merkid.PNG" alt="Merkid" />
    <span>Merkid</span>
  </a>
  <a href="/monsters/fungus-bufo" class="monster-index-card">
    <img src="/assets/Portraits/P_MushroomToad.PNG" alt="Fungus Bufo" />
    <span>Fungus Bufo</span>
  </a>
  <a href="/monsters/imp" class="monster-index-card">
    <img src="/assets/Portraits/P_Imp.PNG" alt="Imp" />
    <span>Imp</span>
  </a>
  <a href="/monsters/bone-crawler" class="monster-index-card">
    <img src="/assets/Portraits/P_BoneCrawler.PNG" alt="Bone Crawler" />
    <span>Bone Crawler</span>
  </a>
  <a href="/monsters/goblin-harpooner" class="monster-index-card">
    <img src="/assets/Portraits/P_GoblinFisher.PNG" alt="Goblin Harpooner" />
    <span>Goblin Harpooner</span>
  </a>
  <a href="/monsters/brachillo" class="monster-index-card">
    <img src="/assets/Portraits/P_Brachillo.PNG" alt="Brachillo" />
    <span>Brachillo</span>
  </a>
  <a href="/monsters/noodle" class="monster-index-card">
    <img src="/assets/Portraits/P_Noodle.PNG" alt="Noodle" />
    <span>Noodle</span>
  </a>
  <a href="/monsters/solsun" class="monster-index-card">
    <img src="/assets/Portraits/P_Solsun.PNG" alt="Solsun" />
    <span>Solsun</span>
  </a>
  <a href="/monsters/red-slime" class="monster-index-card">
    <img src="/assets/Portraits/P_RedSlime.PNG" alt="Red Slime" />
    <span>Red Slime</span>
  </a>
  <a href="/monsters/green-slime" class="monster-index-card">
    <img src="/assets/Portraits/P_GreenSlime.PNG" alt="Green Slime" />
    <span>Green Slime</span>
  </a>
  <a href="/monsters/blue-slime" class="monster-index-card">
    <img src="/assets/Portraits/P_BlueSlime.PNG" alt="Blue Slime" />
    <span>Blue Slime</span>
  </a>
  <a href="/monsters/yellow-slime" class="monster-index-card">
    <img src="/assets/Portraits/P_YellowSlime.PNG" alt="Yellow Slime" />
    <span>Yellow Slime</span>
  </a>
  <a href="/monsters/wiwo" class="monster-index-card">
    <img src="/assets/Portraits/P_Wiwo.PNG" alt="Wiwo" />
    <span>Wiwo</span>
  </a>
  <a href="/monsters/twitchy-fluff" class="monster-index-card">
    <img src="/assets/Portraits/P_TwitchyFluff.PNG" alt="Twitchy Fluff" />
    <span>Twitchy Fluff</span>
  </a>
  <a href="/monsters/small-tooth" class="monster-index-card">
    <img src="/assets/Portraits/P_SmallTooth.PNG" alt="Small Tooth" />
    <span>Small Tooth</span>
  </a>
  <a href="/monsters/razorbeak" class="monster-index-card">
    <img src="/assets/Portraits/P_RazorbeakCrow.PNG" alt="Razorbeak" />
    <span>Razorbeak</span>
  </a>
  <a href="/monsters/stompal" class="monster-index-card">
    <img src="/assets/Portraits/P_Stompal.PNG" alt="Stompal" />
    <span>Stompal</span>
  </a>
  <a href="/monsters/stinky-plinky" class="monster-index-card">
    <img src="/assets/Portraits/P_StinkyMonkey.PNG" alt="Stinky Plinky" />
    <span>Stinky Plinky</span>
  </a>
  <a href="/monsters/gnome" class="monster-index-card">
    <img src="/assets/Portraits/P_Gnome.PNG" alt="Gnome" />
    <span>Gnome</span>
  </a>
  <a href="/monsters/dragonling" class="monster-index-card">
    <img src="/assets/Portraits/P_Dragonling.PNG" alt="Dragonling" />
    <span>Dragonling</span>
  </a>
  <a href="/monsters/flint-golem" class="monster-index-card">
    <img src="/assets/Portraits/P_FlintGolem.PNG" alt="Flint Golem" />
    <span>Flint Golem</span>
  </a>
  <a href="/monsters/bellotto" class="monster-index-card">
    <img src="/assets/Portraits/P_Bellotto.PNG" alt="Bellotto" />
    <span>Bellotto</span>
  </a>
  <a href="/monsters/ork" class="monster-index-card">
    <img src="/assets/Portraits/P_Ork.PNG" alt="Ork" />
    <span>Ork</span>
  </a>
  <a href="/monsters/northern-warrior" class="monster-index-card">
    <img src="/assets/Portraits/P_PenguinWarrior.PNG" alt="Northern Warrior" />
    <span>Northern Warrior</span>
  </a>
  <a href="/monsters/floating-helmet" class="monster-index-card">
    <img src="/assets/Portraits/P_FloatingHelmet.PNG" alt="Floating Helmet" />
    <span>Floating Helmet</span>
  </a>
  <a href="/monsters/mosshat" class="monster-index-card">
    <img src="/assets/Portraits/P_Mosshat.PNG" alt="Mosshat" />
    <span>Mosshat</span>
  </a>
  <a href="/monsters/gekklar" class="monster-index-card">
    <img src="/assets/Portraits/P_Gekklar.PNG" alt="Gekklar" />
    <span>Gekklar</span>
  </a>
  <a href="/monsters/pott" class="monster-index-card">
    <img src="/assets/Portraits/P_Pott.PNG" alt="Pott" />
    <span>Pott</span>
  </a>
  <a href="/monsters/spikey-guy" class="monster-index-card">
    <img src="/assets/Portraits/P_SpikeyGuy.PNG" alt="Spikey Guy" />
    <span>Spikey Guy</span>
  </a>
  <a href="/monsters/rust-eater" class="monster-index-card">
    <img src="/assets/Portraits/P_RustEater.PNG" alt="Rust Eater" />
    <span>Rust Eater</span>
  </a>
  <a href="/monsters/ignibos" class="monster-index-card">
    <img src="/assets/Portraits/P_Ignibos.PNG" alt="Ignibos" />
    <span>Ignibos</span>
  </a>
  <a href="/monsters/lavapod" class="monster-index-card">
    <img src="/assets/Portraits/P_Lavapod.PNG" alt="Lavapod" />
    <span>Lavapod</span>
  </a>
  <a href="/monsters/amalgameye" class="monster-index-card">
    <img src="/assets/Portraits/P_Amalgameye.PNG" alt="Amalgameye" />
    <span>Amalgameye</span>
  </a>
  <a href="/monsters/naster" class="monster-index-card">
    <img src="/assets/Portraits/P_Naster.PNG" alt="Naster" />
    <span>Naster</span>
  </a>
  <a href="/monsters/plibu" class="monster-index-card">
    <img src="/assets/Portraits/P_Plibu.PNG" alt="Plibu" />
    <span>Plibu</span>
  </a>
  <a href="/monsters/flicko" class="monster-index-card">
    <img src="/assets/Portraits/P_Flicko.PNG" alt="Flicko" />
    <span>Flicko</span>
  </a>
  <a href="/monsters/ornenza" class="monster-index-card">
    <img src="/assets/Portraits/P_Ornenza.PNG" alt="Ornenza" />
    <span>Ornenza</span>
  </a>
  <a href="/monsters/winged-spirit" class="monster-index-card">
    <img src="/assets/Portraits/P_WingedSpirit.PNG" alt="Winged Spirit" />
    <span>Winged Spirit</span>
  </a>
  <a href="/monsters/phenchi" class="monster-index-card">
    <img src="/assets/Portraits/P_Phenchi.PNG" alt="Phenchi" />
    <span>Phenchi</span>
  </a>
  <a href="/monsters/long-slime" class="monster-index-card">
    <img src="/assets/Portraits/P_LongSlime.PNG" alt="Long Slime" />
    <span>Long Slime</span>
  </a>
  <a href="/monsters/corolus" class="monster-index-card">
    <img src="/assets/Portraits/P_Corolus.PNG" alt="Corolus" />
    <span>Corolus</span>
  </a>
  <a href="/monsters/teddo" class="monster-index-card">
    <img src="/assets/Portraits/P_Teddo.PNG" alt="Teddo" />
    <span>Teddo</span>
  </a>
  <a href="/monsters/leggy" class="monster-index-card">
    <img src="/assets/Portraits/P_Leggy.PNG" alt="Leggy" />
    <span>Leggy</span>
  </a>
  <a href="/monsters/steel-head" class="monster-index-card">
    <img src="/assets/Portraits/P_SteelHead.PNG" alt="Steel Head" />
    <span>Steel Head</span>
  </a>
  <a href="/monsters/armored-bird" class="monster-index-card">
    <img src="/assets/Portraits/P_Armored bird.PNG" alt="Armored bird" />
    <span>Armored bird</span>
  </a>
  <a href="/monsters/trianha" class="monster-index-card">
    <img src="/assets/Portraits/P_Trianha.PNG" alt="Trianha" />
    <span>Trianha</span>
  </a>
  <a href="/monsters/forest-sprite" class="monster-index-card">
    <img src="/assets/Portraits/P_ForestSprite.PNG" alt="Forest Sprite" />
    <span>Forest Sprite</span>
  </a>
  <a href="/monsters/wintlet" class="monster-index-card">
    <img src="/assets/Portraits/P_Wintlet.PNG" alt="Wintlet" />
    <span>Wintlet</span>
  </a>
  <a href="/monsters/sharp-bean" class="monster-index-card">
    <img src="/assets/Portraits/P_SharpBean.PNG" alt="Sharp Bean" />
    <span>Sharp Bean</span>
  </a>
  <a href="/monsters/skeleton-servant" class="monster-index-card">
    <img src="/assets/Portraits/P_SkeletonServant.PNG" alt="Skeleton Servant" />
    <span>Skeleton Servant</span>
  </a>
  <a href="/monsters/skeleton-archer" class="monster-index-card">
    <img src="/assets/Portraits/P_SkeletonArcher.PNG" alt="Skeleton Archer" />
    <span>Skeleton Archer</span>
  </a>
  <a href="/monsters/zombie" class="monster-index-card">
    <img src="/assets/Portraits/P_Zombie.PNG" alt="Zombie" />
    <span>Zombie</span>
  </a>
  <a href="/monsters/salty-sailor" class="monster-index-card">
    <img src="/assets/Portraits/P_SaltySailor.PNG" alt="Salty Sailor" />
    <span>Salty Sailor</span>
  </a>
  <a href="/monsters/banshee" class="monster-index-card">
    <img src="/assets/Portraits/P_Banshee.PNG" alt="Banshee" />
    <span>Banshee</span>
  </a>
  <a href="/monsters/hot-banshee" class="monster-index-card">
    <img src="/assets/Portraits/P_HotBanshee.PNG" alt="Hot Banshee" />
    <span>Hot Banshee</span>
  </a>
  <a href="/monsters/ghost-dog" class="monster-index-card">
    <img src="/assets/Portraits/P_GhostDog.PNG" alt="Ghost Dog" />
    <span>Ghost Dog</span>
  </a>
  <a href="/monsters/zombie-goblin" class="monster-index-card">
    <img src="/assets/Portraits/P_ZombieGoblin.PNG" alt="Zombie Goblin" />
    <span>Zombie Goblin</span>
  </a>
  <a href="/monsters/corpse-crop" class="monster-index-card">
    <img src="/assets/Portraits/P_CorpseCrop.PNG" alt="Corpse Crop" />
    <span>Corpse Crop</span>
  </a>
  <a href="/monsters/skunicorn" class="monster-index-card">
    <img src="/assets/Portraits/P_Skunicorn.PNG" alt="Skunicorn" />
    <span>Skunicorn</span>
  </a>
  <a href="/monsters/cute-abomination" class="monster-index-card">
    <img src="/assets/Portraits/P_CuteAbomination.PNG" alt="Cute Abomination" />
    <span>Cute Abomination</span>
  </a>
  <a href="/monsters/disturbing-silhouette" class="monster-index-card">
    <img src="/assets/Portraits/P_DisturbingSilhouette.PNG" alt="Disturbing Silhouette" />
    <span>Disturbing Silhouette</span>
  </a>
  <a href="/monsters/scorched-juggler" class="monster-index-card">
    <img src="/assets/Portraits/P_ScorchedJuggler.PNG" alt="Scorched Juggler" />
    <span>Scorched Juggler</span>
  </a>
  <a href="/monsters/bruxis" class="monster-index-card">
    <img src="/assets/Portraits/P_Bruxis.PNG" alt="Bruxis" />
    <span>Bruxis</span>
  </a>
  <a href="/monsters/baby-shadow" class="monster-index-card">
    <img src="/assets/Portraits/P_Baby Shadow.PNG" alt="Baby Shadow" />
    <span>Baby Shadow</span>
  </a>
  <a href="/monsters/crowmere" class="monster-index-card">
    <img src="/assets/Portraits/P_Crowmere.PNG" alt="Crowmere" />
    <span>Crowmere</span>
  </a>
  <a href="/monsters/ronin-zombie" class="monster-index-card">
    <img src="/assets/Portraits/P_RoninZombie.PNG" alt="Ronin Zombie" />
    <span>Ronin Zombie</span>
  </a>
  <a href="/monsters/saka" class="monster-index-card">
    <img src="/assets/Portraits/P_Saka.PNG" alt="Saka" />
    <span>Saka</span>
  </a>
  <a href="/monsters/candela" class="monster-index-card">
    <img src="/assets/Portraits/P_Candela.PNG" alt="Candela" />
    <span>Candela</span>
  </a>
  <a href="/monsters/illuminator" class="monster-index-card">
    <img src="/assets/Portraits/P_Illuminator.PNG" alt="Illuminator" />
    <span>Illuminator</span>
  </a>
  <a href="/monsters/vampire-kid" class="monster-index-card">
    <img src="/assets/Portraits/P_VampireKid.PNG" alt="Vampire Kid" />
    <span>Vampire Kid</span>
  </a>
  <a href="/monsters/mechanical-cherub" class="monster-index-card">
    <img src="/assets/Portraits/P_MechanicalCherub.PNG" alt="Mechanical Cherub" />
    <span>Mechanical Cherub</span>
  </a>
  <a href="/monsters/molo" class="monster-index-card">
    <img src="/assets/Portraits/P_Molo.PNG" alt="Molo" />
    <span>Molo</span>
  </a>
  <a href="/monsters/plibey" class="monster-index-card">
    <img src="/assets/Portraits/P_Plibey.PNG" alt="Plibey" />
    <span>Plibey</span>
  </a>
  <a href="/monsters/fortifisand" class="monster-index-card">
    <img src="/assets/Portraits/P_Fortifisand.PNG" alt="Fortifisand" />
    <span>Fortifisand</span>
  </a>
  <a href="/monsters/zzoink" class="monster-index-card">
    <img src="/assets/Portraits/P_Zzoink.PNG" alt="Zzoink" />
    <span>Zzoink</span>
  </a>
  <a href="/monsters/burny-fluff" class="monster-index-card">
    <img src="/assets/Portraits/P_BurnyFluff.PNG" alt="Burny Fluff" />
    <span>Burny Fluff</span>
  </a>
  <a href="/monsters/vengeful-doll" class="monster-index-card">
    <img src="/assets/Portraits/P_VengefulDoll.PNG" alt="Vengeful Doll" />
    <span>Vengeful Doll</span>
  </a>
  <a href="/monsters/slimbones" class="monster-index-card">
    <img src="/assets/Portraits/P_Slimbones.PNG" alt="Slimbones" />
    <span>Slimbones</span>
  </a>
  <a href="/monsters/living-tome" class="monster-index-card">
    <img src="/assets/Portraits/P_LivingTome.PNG" alt="Living Tome" />
    <span>Living Tome</span>
  </a>
  <a href="/monsters/trumpet-skeleton" class="monster-index-card">
    <img src="/assets/Portraits/P_TrumpetSkeleton.PNG" alt="Trumpet Skeleton" />
    <span>Trumpet Skeleton</span>
  </a>
  </div>
</details>

<details class="monster-tier-group">
  <summary class="monster-tier-summary">Tier 2 <span class="tier-count">27</span></summary>
  <div class="monster-index-grid">
  <a href="/monsters/torch-demon" class="monster-index-card">
    <img src="/assets/Portraits/P_TorchDemon.PNG" alt="Torch Demon" />
    <span>Torch Demon</span>
  </a>
  <a href="/monsters/druidmmer" class="monster-index-card">
    <img src="/assets/Portraits/P_HammerDruid.PNG" alt="Druidmmer" />
    <span>Druidmmer</span>
  </a>
  <a href="/monsters/blue-jigou" class="monster-index-card">
    <img src="/assets/Portraits/P_LostYeti.PNG" alt="Blue Jigou" />
    <span>Blue Jigou</span>
  </a>
  <a href="/monsters/goblin-gunner" class="monster-index-card">
    <img src="/assets/Portraits/P_GoblinGunner.PNG" alt="Goblin Gunner" />
    <span>Goblin Gunner</span>
  </a>
  <a href="/monsters/raging-gunner" class="monster-index-card">
    <img src="/assets/Portraits/P_RagingGunner.PNG" alt="Raging Gunner" />
    <span>Raging Gunner</span>
  </a>
  <a href="/monsters/floating-armor" class="monster-index-card">
    <img src="/assets/Portraits/P_FloatingArmor.PNG" alt="Floating Armor" />
    <span>Floating Armor</span>
  </a>
  <a href="/monsters/wereshark" class="monster-index-card">
    <img src="/assets/Portraits/P_Wereshark.PNG" alt="Wereshark" />
    <span>Wereshark</span>
  </a>
  <a href="/monsters/anura-fighter" class="monster-index-card">
    <img src="/assets/Portraits/P_AmphibianSage.PNG" alt="Anura Fighter" />
    <span>Anura Fighter</span>
  </a>
  <a href="/monsters/rotspore-brute" class="monster-index-card">
    <img src="/assets/Portraits/P_RotsporeBrute.PNG" alt="Rotspore Brute" />
    <span>Rotspore Brute</span>
  </a>
  <a href="/monsters/merfolk-lancer" class="monster-index-card">
    <img src="/assets/Portraits/P_MerfolkLancer.PNG" alt="Merfolk Lancer" />
    <span>Merfolk Lancer</span>
  </a>
  <a href="/monsters/drowned-bucaneer" class="monster-index-card">
    <img src="/assets/Portraits/P_DrownedBucaneer.PNG" alt="Drowned Bucaneer" />
    <span>Drowned Bucaneer</span>
  </a>
  <a href="/monsters/mechanical-angel" class="monster-index-card">
    <img src="/assets/Portraits/P_MechanicalAngel.PNG" alt="Mechanical Angel" />
    <span>Mechanical Angel</span>
  </a>
  <a href="/monsters/cog-knight" class="monster-index-card">
    <img src="/assets/Portraits/P_CogKnight.PNG" alt="Cog-Knight" />
    <span>Cog-Knight</span>
  </a>
  <a href="/monsters/scale-disciple" class="monster-index-card">
    <img src="/assets/Portraits/P_ScaleDisciple.PNG" alt="Scale Disciple" />
    <span>Scale Disciple</span>
  </a>
  <a href="/monsters/wave-creeper" class="monster-index-card">
    <img src="/assets/Portraits/P_WaveCreeper.PNG" alt="Wave Creeper" />
    <span>Wave Creeper</span>
  </a>
  <a href="/monsters/vampire-adept" class="monster-index-card">
    <img src="/assets/Portraits/P_VampireAdept.PNG" alt="Vampire Adept" />
    <span>Vampire Adept</span>
  </a>
  <a href="/monsters/skullhead" class="monster-index-card">
    <img src="/assets/Portraits/P_Skullhead.PNG" alt="Skullhead" />
    <span>Skullhead</span>
  </a>
  <a href="/monsters/stottro" class="monster-index-card">
    <img src="/assets/Portraits/P_Stottro.PNG" alt="Stottro" />
    <span>Stottro</span>
  </a>
  <a href="/monsters/cloud-drake" class="monster-index-card">
    <img src="/assets/Portraits/P_CloudDrake.PNG" alt="Cloud Drake" />
    <span>Cloud Drake</span>
  </a>
  <a href="/monsters/chameledrake" class="monster-index-card">
    <img src="/assets/Portraits/P_Chameledrake.PNG" alt="Chameledrake" />
    <span>Chameledrake</span>
  </a>
  <a href="/monsters/draconid-ranger" class="monster-index-card">
    <img src="/assets/Portraits/P_DraconidRanger.PNG" alt="Draconid Ranger" />
    <span>Draconid Ranger</span>
  </a>
  <a href="/monsters/floro" class="monster-index-card">
    <img src="/assets/Portraits/P_Floro.PNG" alt="Floro" />
    <span>Floro</span>
  </a>
  <a href="/monsters/righteous-hand" class="monster-index-card">
    <img src="/assets/Portraits/P_RighteousHand.PNG" alt="Righteous Hand" />
    <span>Righteous Hand</span>
  </a>
  <a href="/monsters/gle-sha" class="monster-index-card">
    <img src="/assets/Portraits/P_GleSha.PNG" alt="Gle Sha" />
    <span>Gle Sha</span>
  </a>
  <a href="/monsters/karma-hand" class="monster-index-card">
    <img src="/assets/Portraits/P_KarmaHand.PNG" alt="Karma Hand" />
    <span>Karma Hand</span>
  </a>
  <a href="/monsters/anchored-soul" class="monster-index-card">
    <img src="/assets/Portraits/P_AnchoredSoul.PNG" alt="Anchored Soul" />
    <span>Anchored Soul</span>
  </a>
  <a href="/monsters/sunchi" class="monster-index-card">
    <img src="/assets/Portraits/P_Sunchi.PNG" alt="Sunchi" />
    <span>Sunchi</span>
  </a>
  </div>
</details>

<details class="monster-tier-group">
  <summary class="monster-tier-summary">Tier 3 <span class="tier-count">4</span></summary>
  <div class="monster-index-grid">
  <a href="/monsters/vertebral-corsair" class="monster-index-card">
    <img src="/assets/Portraits/P_VertebralCorsair.PNG" alt="Vertebral Corsair" />
    <span>Vertebral Corsair</span>
  </a>
  <a href="/monsters/infernal-blade" class="monster-index-card">
    <img src="/assets/Portraits/P_InfernalBlade.PNG" alt="Infernal Blade" />
    <span>Infernal Blade</span>
  </a>
  <a href="/monsters/ferrous-knuckle" class="monster-index-card">
    <img src="/assets/Portraits/P_FerrousKnuckle.PNG" alt="Ferrous Knuckle" />
    <span>Ferrous Knuckle</span>
  </a>
  <a href="/monsters/stormwing" class="monster-index-card">
    <img src="/assets/Portraits/P_Stormwing.PNG" alt="Stormwing" />
    <span>Stormwing</span>
  </a>
  </div>
</details>

<details class="monster-tier-group">
  <summary class="monster-tier-summary">Other <span class="tier-count">1</span></summary>
  <div class="monster-index-grid">
  <a href="/monsters/zombie-slime" class="monster-index-card">
    <img src="/assets/Portraits/P_ZombieSlime.PNG" alt="Zombie Slime" />
    <span>Zombie Slime</span>
  </a>
  </div>
</details>
