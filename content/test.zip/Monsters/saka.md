---
title: Saka
tags: [neutral, slash, tier1]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Saka</span>
    <a href="/tags/tier1" class="monster-tier">Tier 1</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_Saka.PNG" alt="Saka" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/neutral" class="type-badge"><img src="/assets/icons/T_EType_Normal.PNG" alt="Neutral" class="type-icon" /></a>
      <a href="/tags/slash" class="type-badge"><img src="/assets/icons/T_AType_Slash.PNG" alt="Slash" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    It hunts at night and sleeps during the day. Sometimes it gets confused, but if it doesn't hunt well during the day it gets frustrated.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>55</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>65</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>35</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>40</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>40</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>60</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/draining-bite">Draining Bite</a><br/><span class="skill-desc">User heals for 30% max Health.</span></td></tr>
          <tr><td>5</td><td><a href="/skills/hex">Hex</a><br/><span class="skill-desc">Inflicts 2 <img id="Weak"/> Weak.</span></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/vampirism"><strong>Vampirism</strong></a></br> When attacking a monster with <img id="Weak"/> Weak, restore 30% Max Health.</p>
    </div>
  </div>


</div>