---
title: Anura Fighter
tags: [nature, strike, tier2]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Anura Fighter</span>
    <a href="/tags/tier2" class="monster-tier">Tier 2</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_AmphibianSage.PNG" alt="Anura Fighter" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/nature" class="type-badge"><img src="/assets/icons/T_EType_Nature.PNG" alt="Nature" class="type-icon" /></a>
      <a href="/tags/strike" class="type-badge"><img src="/assets/icons/T_AType_Strike.PNG" alt="Strike" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    —
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>60</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>65</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>45</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>60</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>40</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>61</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/poison-touch">Poison Touch</a><br/><span class="skill-desc">Inflicts 3 <img id="Poison"/> Poison.</span></td></tr>
          <tr><td>8</td><td><a href="/skills/vile-smash">Vile Smash</a></td></tr>
          <tr><td>18</td><td><a href="/skills/contagion">Contagion</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/"><strong>—</strong></a></br> </p>
    </div>
  </div>


</div>