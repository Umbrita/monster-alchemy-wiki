---
title: Spikey Guy
tags: [nature, slash, tier1]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Spikey Guy</span>
    <a href="/tags/tier1" class="monster-tier">Tier 1</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_SpikeyGuy.PNG" alt="Spikey Guy" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/nature" class="type-badge"><img src="/assets/icons/T_EType_Nature.PNG" alt="Nature" class="type-icon" /></a>
      <a href="/tags/slash" class="type-badge"><img src="/assets/icons/T_AType_Slash.PNG" alt="Slash" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    They are quite solitary.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>70</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>65</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>55</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>30</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>30</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>40</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/thorn-strike">Thorn Strike</a></td></tr>
          <tr><td>5</td><td><a href="/skills/thorn-shot">Thorn Shot</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/spike-cuirass"><strong>Spike Cuirass</strong></a></br> Gain 3  Thorns at battle start.</p>
    </div>
  </div>

</div>