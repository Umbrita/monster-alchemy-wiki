---
title: Burny Fluff
tags: [fire, projectile, tier1]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Burny Fluff</span>
    <a href="/tags/tier1" class="monster-tier">Tier 1</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_BurnyFluff.PNG" alt="Burny Fluff" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/fire" class="type-badge"><img src="/assets/icons/T_EType_Fire.PNG" alt="Fire" class="type-icon" /></a>
      <a href="/tags/projectile" class="type-badge"><img src="/assets/icons/T_AType_Projectile.PNG" alt="Projectile" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    It lives in a constant state of panic because it is burning. But its fur resists fire so it is not really in danger.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>52</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>42</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>35</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>65</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>45</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>50</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/pyroclast">Pyroclast</a></td></tr>
          <tr><td>5</td><td><a href="/skills/heat-wave">Heat Wave</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/static-fur"><strong>Static Fur</strong></a></br> When hit by an attack, inflict 1  Shock to the attacker.</p>
    </div>
  </div>
  <div class="monster-drops">
    <h3>Drops</h3>
    <table>
      <thead>
        <tr><th>Rarity</th><th>Drop</th></tr>
      </thead>
      <tbody>
        <tr><td>Common</td><td><a href="/items/roughfur"><img src="/assets/Items/T_RoughFur.PNG" alt="RoughFur" class="drop-icon" />RoughFur</a></td></tr>
      </tbody>
    </table>
  </div>
</div>