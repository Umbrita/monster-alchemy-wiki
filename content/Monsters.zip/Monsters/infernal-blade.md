---
title: Infernal Blade
tags: [fire, slash, tier3]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Infernal Blade</span>
    <a href="/tags/tier3" class="monster-tier">Tier 3</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_InfernalBlade.PNG" alt="Infernal Blade" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/fire" class="type-badge"><img src="/assets/icons/T_EType_Fire.PNG" alt="Fire" class="type-icon" /></a>
      <a href="/tags/slash" class="type-badge"><img src="/assets/icons/T_AType_Slash.PNG" alt="Slash" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    —
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>90</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>130</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>60</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>60</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>60</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>100</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/mud-ball">Mud Ball</a></td></tr>
          <tr><td>5</td><td><a href="/skills/wave-rush">Wave Rush</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block">—</p>
    </div>
  </div>

</div>