---
title: Stormwing
tags: [energy, slash, tier3]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Stormwing</span>
    <a href="/tags/tier3" class="monster-tier">Tier 3</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_Stormwing.PNG" alt="Stormwing" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/energy" class="type-badge"><img src="/assets/icons/T_EType_Energy.PNG" alt="Energy" class="type-icon" /></a>
      <a href="/tags/slash" class="type-badge"><img src="/assets/icons/T_AType_Slash.PNG" alt="Slash" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    Its wings are made of electricity; the more charge it builds the larger they grow.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>80</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>150</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>45</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>60</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>45</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>100</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/swift-slash">Swift Slash</a></td></tr>
          <tr><td>8</td><td><a href="/skills/discharge">Discharge</a></td></tr>
          <tr><td>18</td><td><a href="/skills/deep-rend">Deep Rend</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/energized-plumage"><strong>Energized Plumage</strong></a></br> After using a  attack, inflict  Shock to the target.</p>
    </div>
  </div>

</div>