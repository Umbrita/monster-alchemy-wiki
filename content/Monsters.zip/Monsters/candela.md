---
title: Candela
tags: [fire, strike, tier1]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Candela</span>
    <a href="/tags/tier1" class="monster-tier">Tier 1</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_Candela.PNG" alt="Candela" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/fire" class="type-badge"><img src="/assets/icons/T_EType_Fire.PNG" alt="Fire" class="type-icon" /></a>
      <a href="/tags/strike" class="type-badge"><img src="/assets/icons/T_AType_Strike.PNG" alt="Strike" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    —
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>45</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>35</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>40</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>55</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>55</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>69</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/scorch-blast">Scorch Blast</a></td></tr>
          <tr><td>5</td><td><a href="/skills/wave-rush">Wave Rush</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/candle-wax"><strong>Candle Wax</strong></a></br> When a monster in your team uses a  skill, give it 1  Barrier.</p>
    </div>
  </div>

</div>