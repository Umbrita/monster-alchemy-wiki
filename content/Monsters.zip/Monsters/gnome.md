---
title: Gnome
tags: [nature, strike, tier1]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Gnome</span>
    <a href="/tags/tier1" class="monster-tier">Tier 1</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_Gnome.PNG" alt="Gnome" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/nature" class="type-badge"><img src="/assets/icons/T_EType_Nature.PNG" alt="Nature" class="type-icon" /></a>
      <a href="/tags/strike" class="type-badge"><img src="/assets/icons/T_AType_Strike.PNG" alt="Strike" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    No one knows where it gets its club to attack.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>40</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>42</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>47</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>31</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>60</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>60</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/bloom-bash">Bloom Bash</a></td></tr>
          <tr><td>18</td><td><a href="/skills/trick">Trick</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/lucky"><strong>Lucky</strong></a></br> Obtain rarer rewards after battle.</p>
    </div>
  </div>
  <div class="monster-drops">
    <h3>Drops</h3>
    <table>
      <thead>
        <tr><th>Rarity</th><th>Drop</th></tr>
      </thead>
      <tbody>
        <tr><td>Common</td><td><a href="/items/coin"><img src="/assets/Items/T_Coin.PNG" alt="Coin" class="drop-icon" />Coin</a></td></tr>
        <tr><td>Epic</td><td><a href="/items/healthpotion"><img src="/assets/Items/T_HealthPotion.PNG" alt="HealthPotion" class="drop-icon" />HealthPotion</a></td></tr>
      </tbody>
    </table>
  </div>
</div>