---
title: Pott
tags: [neutral, projectile, tier1]
---
<div class="monster-card">
  <div class="monster-header">
    <span class="monster-name">Pott</span>
    <a href="/tags/tier1" class="monster-tier">Tier 1</a>
  </div>
  <div class="monster-image-wrap">
    <img src="/assets/Portraits/P_Pott.PNG" alt="Pott" class="monster-img" />
    <div class="monster-types">
      <a href="/tags/neutral" class="type-badge"><img src="/assets/icons/T_EType_Normal.PNG" alt="Neutral" class="type-icon" /></a>
      <a href="/tags/projectile" class="type-badge"><img src="/assets/icons/T_AType_Projectile.PNG" alt="Projectile" class="type-icon" /></a>
    </div>
  </div>
  <div class="monster-desc">
    They can't stop generating corrosive acid because they feed on stones. They leave everything a mess.
  </div>
  <div class="monster-stats-row">
    <div class="stat-pill stat-hp"><span>HP</span><strong>45</strong></div>
    <div class="stat-pill stat-str"><span>STR</span><strong>40</strong></div>
    <div class="stat-pill stat-def"><span>DEF</span><strong>40</strong></div>
    <div class="stat-pill stat-mnd"><span>MND</span><strong>55</strong></div>
    <div class="stat-pill stat-soul"><span>SOUL</span><strong>55</strong></div>
    <div class="stat-pill stat-agi"><span>AGI</span><strong>64</strong></div>
  </div>
  <div class="monster-skills-section">
    <div class="skills-active">
      <h3>Active Skills</h3>
      <table>
        <thead>
          <tr><th>Level</th><th>Skill</th></tr>
        </thead>
        <tbody>
          <tr><td>Base</td><td><a href="/skills/acid-bomb">Acid Bomb</a></td></tr>
          <tr><td>5</td><td><a href="/skills/heavy-strike">Heavy Strike</a></td></tr>
        </tbody>
      </table>
    </div>
    <div class="skills-passive">
      <h3>Passive</h3>
      <p class="passive-block"><a href="/passives/acidic-saliva"><strong>Acidic Saliva</strong></a></br> After using a  attack inflict 2  Poison to the target.</p>
    </div>
  </div>

</div>